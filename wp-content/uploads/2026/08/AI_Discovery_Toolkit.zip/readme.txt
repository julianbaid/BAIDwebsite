# AI Discovery Toolkit for UK Small & Medium Businesses

A free, self-guided toolkit to help business owners and managers find out where
AI is already being used in their organisation — knowingly or not — and put a
simple, proportionate plan in place to manage it.

Works in Excel, Google Sheets, and LibreOffice Calc, and Microsoft Word / Google
Docs / LibreOffice Writer. No sign-up, no add-ins, no cost.

## What's in this toolkit

**1. AI_Discovery_Workflow_Toolkit.xlsx** — the main tool. Use this first.
An interactive workbook with:
- A step-by-step "Start Here" guide, including how to distribute it to a team
  using a mix of Microsoft, Google, and other platforms
- A checklist for AI tools you've knowingly adopted
- An audit of AI features hiding inside everyday software (CRM, accounting,
  marketing, HR, etc.)
- A staff survey for "shadow AI" — personal AI tools used for work without
  the business knowing
- A Risk Summary dashboard that calculates itself automatically as you fill
  in the other tabs
- A 7-step Trust Plan with an owner, due date, and status for each action

**2. AI_Usage_Discovery_Checklist_and_Trust_Report.docx** — optional, for later.
A polished Word report template for anyone who wants to turn their workbook
findings into a formal written report — useful if you want to present results
to a board, investors, or an insurer, or simply keep a dated record on file.
Mirrors the same structure as the workbook, plus a benefits-vs-risks summary,
a risk matrix, and a sign-off section.

## Recommended flow

1. Work through the Excel workbook, start to finish — it's the whole exercise
   in one file, and the Risk Summary tab does the analysis for you automatically.
2. If you want a written report to share or file, copy your findings into the
   Word template and fill in the narrative sections.
3. Revisit both every quarter, or whenever you adopt new software.

## A note on UK data protection

UK GDPR does not prohibit small businesses from using AI. It does require you
to know which AI providers process which data, have a lawful basis for that
processing, and be transparent with customers and staff when AI affects them.
This toolkit is a practical starting point, not legal advice — the Information
Commissioner's Office (ico.org.uk) publishes free, up-to-date guidance on AI
and data protection for organisations of every size.

## Licence

Free to use, copy, adapt, and share with other business owners. No attribution
required.