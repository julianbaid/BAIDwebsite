# Supplier AI Audit Toolkit

A free, self-guided companion toolkit for UK small and medium businesses.
Audits the AI your suppliers use — your accountant, marketing agency, courier,
and software providers — and checks whether their AI-driven savings are
actually reaching you.

Works in Excel, Google Sheets, and LibreOffice Calc, on Windows, Mac, or
mobile. No sign-up, no add-ins, no cost.

## What's in this toolkit

**Supplier_AI_Audit_Toolkit.xlsx** — the whole exercise in one workbook:

- A step-by-step "Start Here" guide
- A supplier list with a 5-question quick check for everyone who touches
  your data, money, or customers
- An 18-question deep-dive audit (AI use, data, cost, risk & responsibility)
  for your highest-priority suppliers, laid out so you can compare several
  suppliers side by side
- Ready-made questions by supplier type — accountants, marketing agencies,
  couriers, and IT/software providers
- A cost & savings tracker to check whether AI has cut your supplier's
  costs, and whether any of that has reached your price
- A Risk Summary dashboard that calculates itself automatically
- A 7-step action plan, proportionate and non-adversarial

## How to use it

1. Work through Tab 2 for every supplier that touches your data, money, or
   customers — most people can do this in under an hour.
2. Run the full 18-question audit (Tab 3) on your two or three
   highest-priority suppliers, using the ready-made questions in Tab 5.
3. Fill in the cost tracker (Tab 4) — this is the one most businesses skip,
   and it's usually the most valuable.
4. Check the Risk Summary tab for anything flagged red or amber.
5. Work through the action plan and revisit annually, or whenever a supplier
   tells you about a new AI feature.

## Pairs with

The **AI Discovery Workflow Toolkit** — the same approach applied inside
your own business, covering tools you've adopted, AI built into your
software, and AI your own staff bring in informally.

## A note on UK data protection

UK GDPR generally holds you accountable as the data controller even when a
third-party supplier causes a breach. This toolkit is a practical starting
point, not legal advice — the Information Commissioner's Office
(ico.org.uk) publishes free, up-to-date guidance on contracts, third
parties, and AI.

## Licence

Free to use, copy, adapt, and share with other business owners. No
attribution required.
